import customtkinter as ctk
from tkinter import StringVar, IntVar
from PIL import Image
from database import get_db_connection
import subprocess

BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"
WINDOW_BG = "#F6F6F6"

class BrowseProductsView:
    def __init__(self, parent, user_id, cart):
        self.user_id = user_id
        self.cart = cart
        self.products = []

        self.cart_count = IntVar(value=sum(cart.values()))
        self.search_var = StringVar()

        # Search and Cart
        search_frame = ctk.CTkFrame(parent, fg_color=WINDOW_BG)
        search_frame.pack(fill="x", padx=20, pady=(10, 0))

        search_entry = ctk.CTkEntry(search_frame, textvariable=self.search_var, width=400,
                                    placeholder_text="Search for products...",
                                    fg_color=BUTTON_COLOR, text_color=TEXT_COLOR)
        search_entry.pack(side="left", padx=10)
        search_entry.bind("<KeyRelease>", self.filter_products)

        self.cart_button = ctk.CTkButton(search_frame, text=f"Cart ({self.cart_count.get()})",
                                         fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                                         command=self.go_to_cart)
        self.cart_button.pack(side="right", padx=10)

        # Product List
        self.product_frame = ctk.CTkScrollableFrame(parent, fg_color=WINDOW_BG)
        self.product_frame.pack(fill="both", expand=True, padx=20, pady=10)

        self.load_products()

    def load_products(self):
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM products")
        self.products = cursor.fetchall()
        conn.close()
        self.display_products(self.products)

    def display_products(self, product_list):
        for widget in self.product_frame.winfo_children():
            widget.destroy()

        for product in product_list:
            self.create_product_card(product)

    def create_product_card(self, product):
        frame = ctk.CTkFrame(self.product_frame, fg_color=BUTTON_COLOR, corner_radius=10)
        frame.pack(fill="x", pady=5, padx=10)

        try:
            img = Image.open(product["image"]).resize((100, 100))
            img = ctk.CTkImage(img, size=(100, 100))
        except:
            img = None

        ctk.CTkLabel(frame, image=img, text="").pack(side="left", padx=10)
        details = f"{product['name']}\n💰 ${product['price']}\n📦 Stock: {product['stock']}"
        ctk.CTkLabel(frame, text=details, font=("Arial", 12), text_color=TEXT_COLOR).pack(side="left", padx=10)

        productid = product["productid"]
        quantity_var = IntVar(value=self.cart.get(productid, 0))
        button_frame = ctk.CTkFrame(frame, fg_color=BUTTON_COLOR)

        def update_ui():
            if quantity_var.get() == 0:
                add_btn.pack(side="right", padx=10)
                button_frame.pack_forget()
            else:
                add_btn.pack_forget()
                button_frame.pack(side="right", padx=10)
            self.update_cart(productid, quantity_var.get())

        def increase(): quantity_var.set(quantity_var.get() + 1); update_ui()
        def decrease():
            quantity_var.set(max(0, quantity_var.get() - 1))
            update_ui()

        ctk.CTkButton(button_frame, text="➖", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      command=decrease, width=30).pack(side="left")
        ctk.CTkLabel(button_frame, textvariable=quantity_var, text_color=TEXT_COLOR).pack(side="left", padx=5)
        ctk.CTkButton(button_frame, text="➕", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      command=increase, width=30).pack(side="left")

        add_btn = ctk.CTkButton(frame, text="Add to Cart", fg_color=HIGHLIGHT_COLOR,
                                text_color="white", command=lambda: [increase()])
        add_btn.pack(side="right", padx=10)

        update_ui()

    def update_cart(self, pid, qty):
        if qty > 0:
            self.cart[pid] = qty
        else:
            self.cart.pop(pid, None)
        self.cart_count.set(sum(self.cart.values()))
        self.cart_button.configure(text=f"Cart ({self.cart_count.get()})")

    def filter_products(self, event):
        query = self.search_var.get().lower()
        filtered = [p for p in self.products if query in p["name"].lower()]
        self.display_products(filtered)

    def go_to_cart(self):
        with open("cart_session.txt", "w") as f:
            f.write(str({self.user_id: self.cart}))

        # Destroy the main window (close dashboard)
        root = self.cart_button.winfo_toplevel()
        root.destroy()

        subprocess.Popen(["python", "cart.py", str(self.user_id)])