import customtkinter as ctk
from PIL import Image
import subprocess
import sys

from browse_products_view import BrowseProductsView
from orders_view import OrdersView

# === Color Scheme ===
SIDEBAR_COLOR = "#322F77"
BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
WINDOW_BG = "#F6F6F6"

class CustomerDashboard(ctk.CTk):
    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.cart = {}

        self.title("Customer Dashboard")
        self.geometry("950x650")
        self.configure(fg_color=WINDOW_BG)

        # === Sidebar ===
        self.sidebar = ctk.CTkFrame(self, width=220, fg_color=SIDEBAR_COLOR, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")

        ctk.CTkLabel(self.sidebar, text="Welcome!", font=("Arial", 18, "bold"), text_color="white").pack(pady=(20, 5))
        ctk.CTkLabel(self.sidebar, text=f"User {self.user_id}", font=("Arial", 14), text_color="white").pack(pady=(0, 20))

        # Buttons with image icons and outer padding
        self.add_nav_button("Browse Products", "icons/products.png", self.show_browse_products)
        self.add_nav_button("View Orders", "icons/orders.png", self.show_orders)

        ctk.CTkLabel(self.sidebar, text="").pack(expand=True)  # Spacer

        # Logout button at bottom
        self.add_nav_button("Logout", "icons/logout.png", self.logout, bottom=True)

        # === Main Frame ===
        self.main_frame = ctk.CTkFrame(self, fg_color=WINDOW_BG)
        self.main_frame.pack(side="left", fill="both", expand=True)

        self.show_browse_products()  # Default View

    def add_nav_button(self, text, image_path, command, bottom=False):
        """Add a sidebar button with image and outer padding."""
        try:
            icon = ctk.CTkImage(Image.open(image_path), size=(20, 20))
        except Exception as e:
            print(f"[ERROR] Could not load icon: {image_path}")
            icon = None

        # Frame for padding
        btn_container = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        if bottom:
            btn_container.pack(side="bottom", fill="x", padx=15, pady=10)
        else:
            btn_container.pack(fill="x", padx=15, pady=10)

        # Button inside padded container
        btn = ctk.CTkButton(btn_container, text=text, image=icon, compound="left",
                            fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                            hover_color="#E5E5E5", anchor="center", width=180, command=command)
        btn.pack(fill="x")

    def clear_main_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

    def show_browse_products(self):
        self.clear_main_frame()
        BrowseProductsView(self.main_frame, self.user_id, self.cart)

    def show_orders(self):
        self.clear_main_frame()
        OrdersView(self.main_frame, self.user_id)

    def logout(self):
        self.destroy()
        subprocess.Popen(["python", "login.py"])

# ========== Run ==========
if __name__ == "__main__":
    if len(sys.argv) > 1:
        user_id = sys.argv[1]
        app = CustomerDashboard(user_id)
        app.mainloop()
    else:
        print("❌ ERROR: No user ID provided!")
