import customtkinter as ctk
import mysql.connector
from database import get_db_connection
from tkinter import messagebox
import subprocess
import sys

# ========== COLOR SCHEME ==========
BG_COLOR = "#322F77"
BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"

class EditUser(ctk.CTk):
    def __init__(self, userid):
        super().__init__()

        self.userid = userid

        self.title("Edit User")
        self.geometry("400x500")
        self.configure(fg_color=BG_COLOR)

        ctk.CTkLabel(self, text="✏ Edit User Details", font=("Arial", 20, "bold"), text_color="white").pack(pady=10)

        # Fetch user details
        user = self.get_user_details()

        if user:
            self.name_entry = ctk.CTkEntry(self, placeholder_text="Full Name", width=300)
            self.name_entry.insert(0, user["name"])
            self.name_entry.pack(pady=5)

            self.username_entry = ctk.CTkEntry(self, placeholder_text="Username", width=300)
            self.username_entry.insert(0, user["username"])
            self.username_entry.pack(pady=5)

            self.email_entry = ctk.CTkEntry(self, placeholder_text="Email", width=300)
            self.email_entry.insert(0, user["email"])
            self.email_entry.pack(pady=5)

            self.phone_entry = ctk.CTkEntry(self, placeholder_text="Phone Number", width=300)
            self.phone_entry.insert(0, user["phone_number"])
            self.phone_entry.pack(pady=5)

            # Update Button
            ctk.CTkButton(self, text="✅ Update", fg_color="green", text_color="white",
                          command=self.update_user).pack(pady=10)

            # Back Button
            ctk.CTkButton(self, text="⬅ Back", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                          hover_color=HIGHLIGHT_COLOR, command=self.go_back).pack(pady=5)

        else:
            ctk.CTkLabel(self, text="⚠️ User not found!", text_color="red").pack(pady=10)

    def get_user_details(self):
        """Fetch user details from database."""
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE userid = %s", (self.userid,))
        user = cursor.fetchone()
        conn.close()
        return user

    def update_user(self):
        """Update user details in database."""
        name = self.name_entry.get().strip()
        username = self.username_entry.get().strip()
        email = self.email_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not username or not email or not phone:
            messagebox.showerror("Error", "All fields are required!")
            return

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET name=%s, username=%s, email=%s, phone_number=%s WHERE userid=%s",
                           (name, username, email, phone, self.userid))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "User details updated successfully!")

            # Close this window and return to ManageUsers
            self.destroy()
            subprocess.Popen(["python", "manage_users.py"])

        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", str(e))

    def go_back(self):
        """Return to Manage Users screen without changes."""
        self.destroy()
        subprocess.Popen(["python", "manage_users.py"])

# Run Application
if __name__ == "__main__":
    if len(sys.argv) > 1:
        userid = sys.argv[1]
        app = EditUser(userid)
        app.mainloop()
    else:
        print("❌ ERROR: User ID required!")
