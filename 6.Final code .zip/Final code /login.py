import customtkinter as ctk
from tkinter import messagebox
import subprocess
from database import get_db_connection
import mysql.connector
from PIL import Image

# Initialize CustomTkinter
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# Create Login Window
root = ctk.CTk()
root.title("Login - Inventory Management System")
root.geometry("800x500")
root.resizable(False, False)

# Define Colors
LEFT_BG_COLOR = "#322F77"
RIGHT_BG_COLOR = "#FFFFFF"
INPUT_COLOR = "#F0F0F0"
BUTTON_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"

# ========== LEFT SIDE PANEL ========== #
left_frame = ctk.CTkFrame(root, width=400, height=500, fg_color=LEFT_BG_COLOR)
left_frame.place(x=0, y=0)

# Add background image to left frame
try:
    image_path = "images/Inventory-Management.jpg"
    bg_img = ctk.CTkImage(light_image=Image.open(image_path), size=(400, 500))
    image_label = ctk.CTkLabel(left_frame, image=bg_img, text="")
    image_label.place(x=0, y=0)
except Exception as e:
    print(f"[ERROR] Could not load left panel image: {e}")

# ========== RIGHT SIDE - LOGIN FORM ========== #
right_frame = ctk.CTkFrame(root, width=400, height=500, fg_color=RIGHT_BG_COLOR)
right_frame.place(x=400, y=0)

# Login Title
ctk.CTkLabel(right_frame, text="Login", font=("Arial", 20, "bold"), text_color="black").place(x=160, y=80)

# Username Entry
ctk.CTkLabel(right_frame, text="Username", text_color="black", font=("Arial", 12)).place(x=50, y=140)
username_entry = ctk.CTkEntry(right_frame, width=300, fg_color=INPUT_COLOR, text_color="black", border_width=1)
username_entry.place(x=50, y=170)

# Password Entry
ctk.CTkLabel(right_frame, text="Password", text_color="black", font=("Arial", 12)).place(x=50, y=210)
password_entry = ctk.CTkEntry(right_frame, width=300, show="*", fg_color=INPUT_COLOR, text_color="black", border_width=1)
password_entry.place(x=50, y=240)

# --- Show Password Toggle ---
def toggle_password():
    if show_password_checkbox.get():
        password_entry.configure(show="")
    else:
        password_entry.configure(show="*")

show_password_checkbox = ctk.CTkCheckBox(
    right_frame,
    text="Show Password",
    text_color="black",
    command=toggle_password
)
show_password_checkbox.place(x=50, y=270)

# --- Login Button ---
def authenticate_user():
    username = username_entry.get().strip()
    password = password_entry.get().strip()

    if not username or not password:
        messagebox.showerror("Error", "All fields are required!")
        return

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
    user = cursor.fetchone()
    conn.close()

    if user:
        if user["status"] != "active":
            messagebox.showerror("Access Denied", "Your account is inactive. Contact admin.")
            return

        root.destroy()
        if user["role"] == "admin":
            subprocess.Popen(["python", "admin_dashboard.py"])
        else:
            subprocess.Popen(["python", "customer_dashboard.py", str(user["userid"])])
    else:
        messagebox.showerror("Error", "Invalid Username or Password")

ctk.CTkButton(right_frame, text="Login", command=authenticate_user, fg_color=BUTTON_COLOR, text_color="white",
              width=300, height=40, corner_radius=5).place(x=50, y=310)

# Sign Up Link
def open_signup():
    root.destroy()
    subprocess.Popen(["python", "signup.py"])

ctk.CTkLabel(right_frame, text="Need to create an account?", text_color="black", font=("Arial", 11)).place(x=80, y=360)
ctk.CTkButton(right_frame, text="Create Account", fg_color=LEFT_BG_COLOR, text_color="white", width=120, height=30,
              command=open_signup, border_width=0).place(x=230, y=357)

# Run App
root.mainloop()
