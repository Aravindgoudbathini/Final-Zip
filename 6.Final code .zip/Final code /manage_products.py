import customtkinter as ctk
from tkinter import messagebox, filedialog
from PIL import Image
import mysql.connector
import subprocess
from database import get_db_connection
import os

# === COLORS ===
SIDEBAR_COLOR = "#322F77"
BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"
WINDOW_BG = "#F6F6F6"

class ManageProducts(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Manage Products")
        self.geometry("1000x600")
        self.configure(fg_color=WINDOW_BG)

        # === SIDEBAR ===
        self.sidebar = ctk.CTkFrame(self, width=220, fg_color=SIDEBAR_COLOR)
        self.sidebar.pack(side="left", fill="y")

        ctk.CTkLabel(self.sidebar, text="📦 Product Panel", font=("Arial", 20, "bold"), text_color="white").pack(pady=(20, 10))
        self.add_nav_button("➕ Add Product", self.show_add_product)
        self.add_nav_button("🔄 Refresh Products", self.load_products)

        ctk.CTkLabel(self.sidebar, text="").pack(expand=True)
        self.add_nav_button("⬅ Back to Admin", self.go_back, bottom=True)

        # === MAIN FRAME ===
        self.main_frame = ctk.CTkScrollableFrame(self, fg_color=WINDOW_BG)
        self.main_frame.pack(side="left", fill="both", expand=True)

        self.load_products()

    def add_nav_button(self, text, command, bottom=False):
        btn = ctk.CTkButton(
            self.sidebar, text=text, fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
            hover_color=HIGHLIGHT_COLOR, command=command, width=180
        )
        if bottom:
            btn.pack(side="bottom", pady=15)
        else:
            btn.pack(pady=8, padx=20)

    def clear_main_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

    def load_products(self):
        self.clear_main_frame()

        # --- Search & Filter UI ---
        filter_frame = ctk.CTkFrame(self.main_frame, fg_color=WINDOW_BG)
        filter_frame.pack(pady=10, padx=20, fill="x")

        # Left container for search/filter fields
        search_filter_container = ctk.CTkFrame(filter_frame, fg_color=WINDOW_BG)
        search_filter_container.pack(side="left", padx=(0, 20))

        # Search Bar
        ctk.CTkLabel(search_filter_container, text="🔍 Search:", text_color=TEXT_COLOR, font=("Arial", 12)).pack(side="left", padx=(0, 5))
        self.search_var = ctk.StringVar()
        search_entry = ctk.CTkEntry(search_filter_container, textvariable=self.search_var, width=200, placeholder_text="Product name")
        search_entry.pack(side="left", padx=(0, 20))

        # Availability Filter
        ctk.CTkLabel(search_filter_container, text="Filter:", text_color=TEXT_COLOR, font=("Arial", 12)).pack(side="left", padx=(0, 5))
        self.availability_filter = ctk.CTkOptionMenu(search_filter_container, values=["All", "available", "not available"])
        self.availability_filter.set("All")
        self.availability_filter.pack(side="left", padx=(0, 20))

        # Search Button on the RIGHT
        ctk.CTkButton(filter_frame, text="🔎 Search", fg_color=HIGHLIGHT_COLOR, text_color="white",
                      command=self.apply_filters).pack(side="right", padx=10)

        # Trigger initial product load
        self.apply_filters()

    def apply_filters(self):
        search_text = self.search_var.get().lower()
        selected_availability = self.availability_filter.get()

        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)

            query = "SELECT * FROM products WHERE 1=1"
            params = []

            if search_text:
                query += " AND LOWER(name) LIKE %s"
                params.append(f"%{search_text}%")

            if selected_availability != "All":
                query += " AND availability = %s"
                params.append(selected_availability)

            query += " ORDER BY productid DESC"
            cursor.execute(query, params)
            products = cursor.fetchall()
            conn.close()
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", str(e))
            return

        for widget in self.main_frame.winfo_children()[1:]:
            widget.destroy()

        if not products:
            ctk.CTkLabel(self.main_frame, text="No products match your criteria.", text_color="red").pack(pady=20)
        else:
            for product in products:
                self.create_product_card(product)

    def create_product_card(self, product):
        card = ctk.CTkFrame(self.main_frame, fg_color=BUTTON_COLOR, corner_radius=10)
        card.pack(padx=20, pady=10, fill="x")

        inner = ctk.CTkFrame(card, fg_color=BUTTON_COLOR)
        inner.pack(fill="x", padx=10, pady=10)

        # === Image ===
        try:
            img_path = product['image']
            if os.path.exists(img_path):
                pil_img = Image.open(img_path).resize((80, 80))
                img = ctk.CTkImage(light_image=pil_img, size=(80, 80))
                ctk.CTkLabel(inner, image=img, text="").pack(side="left", padx=10)
            else:
                ctk.CTkLabel(inner, text="[Image Missing]", text_color="red").pack(side="left", padx=10)
        except:
            ctk.CTkLabel(inner, text="[Image Error]", text_color="red").pack(side="left", padx=10)

        # === Product Info ===
        details = (
            f"ID: {product['productid']}\n"
            f"Name: {product['name']}\n"
            f"Price: ${product['price']}\n"
            f"Stock: {product['stock']}\n"
            f"Availability: {product['availability']}"
        )
        ctk.CTkLabel(inner, text=details, font=("Arial", 12), text_color=TEXT_COLOR).pack(side="left", padx=10)

        # === Action Buttons ===
        action_frame = ctk.CTkFrame(inner, fg_color=BUTTON_COLOR)
        action_frame.pack(side="right")

        ctk.CTkButton(action_frame, text="✏ Update", fg_color=HIGHLIGHT_COLOR, text_color="white",
                      command=lambda: self.update_product_popup(product)).pack(pady=5)

        # ❌ Delete button removed as requested

    def show_add_product(self):
        self.clear_main_frame()

        ctk.CTkLabel(self.main_frame, text="➕ Add New Product", font=("Arial", 20, "bold"), text_color=TEXT_COLOR).pack(pady=20)

        def create_labeled_entry(label_text):
            ctk.CTkLabel(self.main_frame, text=label_text, text_color=TEXT_COLOR, font=("Arial", 12)).pack()
            entry = ctk.CTkEntry(self.main_frame, width=400)
            entry.pack(pady=5)
            return entry

        name = create_labeled_entry("Product Name:")
        desc = create_labeled_entry("Description:")
        price = create_labeled_entry("Price:")
        stock = create_labeled_entry("Stock:")
        image_path_var = ctk.StringVar()

        def browse_image():
            file = filedialog.askopenfilename(filetypes=[("Images", "*.png;*.jpg;*.jpeg")])
            if file:
                image_path_var.set(file)

        ctk.CTkLabel(self.main_frame, text="Image File:", text_color=TEXT_COLOR, font=("Arial", 12)).pack()
        ctk.CTkButton(self.main_frame, text="📷 Browse Image", command=browse_image, width=400).pack(pady=5)

        def submit():
            if not all([name.get(), desc.get(), price.get(), stock.get(), image_path_var.get()]):
                messagebox.showerror("Error", "All fields are required.")
                return
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO products (name, description, price, stock, image, availability) VALUES (%s, %s, %s, %s, %s, %s)",
                    (name.get(), desc.get(), float(price.get()), int(stock.get()), image_path_var.get(), "available")
                )
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", "Product added.")
                self.load_products()
            except Exception as e:
                messagebox.showerror("Database Error", str(e))

        ctk.CTkButton(self.main_frame, text="✅ Submit", fg_color="green", text_color="white",
                      command=submit, width=400).pack(pady=15)

    def update_product_popup(self, product):
        popup = ctk.CTkToplevel(self)
        popup.title("Update Product")
        popup.geometry("400x400")
        popup.grab_set()

        ctk.CTkLabel(popup, text=f"Update: {product['name']}", font=("Arial", 16, "bold")).pack(pady=10)

        def labeled_entry(parent, label, initial=""):
            ctk.CTkLabel(parent, text=label, text_color=TEXT_COLOR, font=("Arial", 12)).pack()
            entry = ctk.CTkEntry(parent, width=300)
            entry.insert(0, str(initial))
            entry.pack(pady=5)
            return entry

        name = labeled_entry(popup, "Name", product['name'])
        price = labeled_entry(popup, "Price", product['price'])
        stock = labeled_entry(popup, "Stock", product['stock'])

        def submit_update():
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute(
                    "UPDATE products SET name=%s, price=%s, stock=%s WHERE productid=%s",
                    (name.get(), float(price.get()), int(stock.get()), product['productid'])
                )
                conn.commit()
                conn.close()
                popup.destroy()
                messagebox.showinfo("Updated", "Product updated successfully.")
                self.load_products()
            except Exception as e:
                messagebox.showerror("Database Error", str(e))

        ctk.CTkButton(popup, text="💾 Save", fg_color=HIGHLIGHT_COLOR, text_color="white", command=submit_update).pack(pady=15)

    def go_back(self):
        self.destroy()
        subprocess.Popen(["python", "admin_dashboard.py"])


# Run
if __name__ == "__main__":
    app = ManageProducts()
    app.mainloop()
