import mysql.connector

# Database Configuration
DB_CONFIG = {
    "host": "141.209.241.57",
    "port": 3306,
    "user": "bathi1a",
    "password": "mypass",
    "database": "BIS698W1700_GRP13"
}

# Function to connect to MySQL
def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

# Function to create the database and tables
def create_database():
    conn = mysql.connector.connect(
        host=DB_CONFIG["host"],
        user=DB_CONFIG["user"],
        password=DB_CONFIG["password"]
    )
    cursor = conn.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS BIS698W1700_GRP13")
    cursor.close()
    conn.close()

    # Reconnect to the new DB
    conn = get_db_connection()
    cursor = conn.cursor()

    # Drop tables for clean setup
    cursor.execute("DROP TABLE IF EXISTS orders, products, users")

    # Users Table — with status field
    cursor.execute("""
    CREATE TABLE users (
        userid VARCHAR(50) PRIMARY KEY,
        firstname VARCHAR(100) NOT NULL,
        lastname VARCHAR(100) NOT NULL,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        phone_number VARCHAR(20) NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'customer') NOT NULL DEFAULT 'customer',
        status ENUM('active', 'inactive') NOT NULL DEFAULT 'active'
    )
    """)

    # Products Table — with availability field
    cursor.execute("""
    CREATE TABLE products (
        productid INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
        stock INT NOT NULL CHECK (stock >= 0),
        image VARCHAR(255) NOT NULL,
        availability ENUM('available', 'not available') NOT NULL DEFAULT 'available'
    )
    """)

    # Orders Table
    cursor.execute("""
    CREATE TABLE orders (
        orderid INT AUTO_INCREMENT PRIMARY KEY,
        userid VARCHAR(50) NOT NULL,
        items TEXT NOT NULL,
        total_price DECIMAL(10,2) NOT NULL CHECK (total_price >= 0),
        status ENUM('pending', 'shipped', 'delivered') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (userid) REFERENCES users(userid)
            ON DELETE CASCADE
            ON UPDATE CASCADE
    )
    """)

    # Insert Users
    default_users = [
        ("U1001", "Admin", "User", "admin", "admin@ims.com", "9876543210", "admin123", "admin", "active"),
        ("U1002", "John", "Doe", "john_doe", "john@example.com", "9234567890", "customer123", "customer", "active"),
        ("U1003", "Jane", "Smith", "jane_smith", "jane@example.com", "9123456789", "customer456", "customer", "inactive"),
    ]
    try:
        cursor.executemany("""
            INSERT INTO users (userid, firstname, lastname, username, email, phone_number, password, role, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, default_users)
    except mysql.connector.IntegrityError:
        print("⚠️ Default users already exist.")

    # Insert Sample Products
    sample_products = [
        ("Laptop", "High-performance laptop.", 899.99, 10, "images/laptop.jpg", "available"),
        ("Smartphone", "Latest model smartphone.", 599.99, 0, "images/phone.jpeg", "not available"),
        ("Headphones", "Wireless noise-canceling headphones.", 199.99, 15, "images/headphones.png", "available"),
        ("Smartwatch", "Fitness tracking smartwatch.", 149.99, 0, "images/smartwatch.png", "not available"),
        ("Camera", "Professional DSLR camera.", 749.99, 8, "images/camera.jpeg", "available"),
    ]
    try:
        cursor.executemany("""
            INSERT INTO products (name, description, price, stock, image, availability)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, sample_products)
    except mysql.connector.IntegrityError:
        print("⚠️ Default products already exist.")

    # Insert Sample Orders
    sample_orders = [
        ("U1002", "Laptop, Headphones", 1099.98, "pending"),
        ("U1003", "Smartphone, Smartwatch", 748.99, "shipped"),
    ]
    try:
        cursor.executemany("""
            INSERT INTO orders (userid, items, total_price, status)
            VALUES (%s, %s, %s, %s)
        """, sample_orders)
    except mysql.connector.IntegrityError:
        print("⚠️ Default orders already exist.")

    conn.commit()
    cursor.close()
    conn.close()
    print("✅ Database setup completed successfully!")

# Run setup
if __name__ == "__main__":
    create_database()
