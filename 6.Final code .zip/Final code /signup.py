import customtkinter as ctk
import subprocess
import mysql.connector
import re
from tkinter import messagebox
from database import get_db_connection
from PIL import Image

# === UI Configuration ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("Sign Up - Inventory Management System")
root.geometry("900x750")
root.resizable(False, False)

# === Colors ===
LEFT_BG = "#322F77"
RIGHT_BG = "#FFFFFF"
INPUT_COLOR = "#F0F0F0"
BUTTON_COLOR = "#322F77"
TEXT_COLOR = "#000000"
HIGHLIGHT_COLOR = "#4F46E5"

# === Left Panel with Image ===
left_frame = ctk.CTkFrame(root, width=450, height=750, fg_color="white")
left_frame.place(x=0, y=0)

try:
    from PIL import ImageTk

    original = Image.open("images/Inventory-Management.jpg").resize((450, 650))
    full_image = ctk.CTkImage(light_image=original, size=(450, 650))
    ctk.CTkLabel(left_frame, image=full_image, text="").place(x=0, y=0, relwidth=1, relheight=1)
except Exception as e:
    print(f"[ERROR] Could not load full-size image: {e}")
    ctk.CTkLabel(left_frame, text="Welcome to IMS", font=("Arial", 20, "bold"), text_color="white").place(relx=0.5, rely=0.5, anchor="center")


# === Right Form Panel ===
form_frame = ctk.CTkFrame(root, width=450, height=750, fg_color=RIGHT_BG)
form_frame.place(x=450, y=0)

# === Entry Helper Function ===
def create_input(label, ypos, password=False):
    ctk.CTkLabel(form_frame, text=label, font=("Arial", 12), text_color=TEXT_COLOR).place(x=50, y=ypos)
    entry = ctk.CTkEntry(form_frame, width=330, fg_color=INPUT_COLOR, text_color=TEXT_COLOR, show="*" if password else "")
    entry.place(x=50, y=ypos + 30)
    return entry

# === Form Fields ===
userid_entry = create_input("User ID", 80)
username_entry = create_input("Username", 140)
firstname_entry = create_input("First Name", 200)
lastname_entry = create_input("Last Name", 260)
email_entry = create_input("Email", 320)
phone_entry = create_input("Phone Number", 380)
password_entry = create_input("Password", 440, password=True)
confirm_entry = create_input("Confirm Password", 500, password=True)

# === Validation Functions ===
def is_valid_email(email): return re.match(r"[^@]+@[^@]+\.[^@]+", email)
def is_valid_phone(phone): return re.match(r"^\d{10}$", phone)
def is_valid_password(pwd): return re.match(r"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{8,}$", pwd)

def check_existing_user(userid, username, email):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT 1 FROM users WHERE userid = %s", (userid,))
    id_exists = cursor.fetchone()
    cursor.execute("SELECT 1 FROM users WHERE username = %s", (username,))
    uname_exists = cursor.fetchone()
    cursor.execute("SELECT 1 FROM users WHERE email = %s", (email,))
    email_exists = cursor.fetchone()
    conn.close()
    return id_exists, uname_exists, email_exists

# === Register User Function ===
def register_user():
    userid = userid_entry.get().strip()
    username = username_entry.get().strip()
    firstname = firstname_entry.get().strip()
    lastname = lastname_entry.get().strip()
    email = email_entry.get().strip()
    phone = phone_entry.get().strip()
    password = password_entry.get().strip()
    confirm = confirm_entry.get().strip()

    # === Collect all error messages ===
    errors = []

    if not userid: errors.append("• User ID is required.")
    if not username: errors.append("• Username is required.")
    if not firstname: errors.append("• First Name is required.")
    if not lastname: errors.append("• Last Name is required.")
    if not email: errors.append("• Email is required.")
    elif not is_valid_email(email): errors.append("• Invalid email format.")
    if not phone: errors.append("• Phone number is required.")
    elif not is_valid_phone(phone): errors.append("• Phone number must be 10 digits.")
    if not password: errors.append("• Password is required.")
    elif not is_valid_password(password):
        errors.append("• Password must have 8+ characters with upper, lower, and digit.")
    if not confirm: errors.append("• Please confirm your password.")
    elif confirm != password: errors.append("• Passwords do not match.")

    # Show errors if any
    if errors:
        messagebox.showerror("Validation Errors", "\n".join(errors))
        return

    # Check if exists
    id_exists, uname_exists, email_exists = check_existing_user(userid, username, email)
    if id_exists: return messagebox.showerror("Error", "User ID already exists.")
    if uname_exists: return messagebox.showerror("Error", "Username already exists.")
    if email_exists: return messagebox.showerror("Error", "Email already registered.")

    # ✅ Save to DB
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO users (userid, firstname, lastname, username, email, phone_number, password, role)
            VALUES (%s, %s, %s, %s, %s, %s, %s, 'customer')
        """, (userid, firstname, lastname, username, email, phone, password))
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", f"Account created successfully!\nWelcome, {firstname}!")
        root.destroy()
        subprocess.Popen(["python", "login.py"])
    except mysql.connector.Error as e:
        messagebox.showerror("Database Error", f"Something went wrong:\n{e}")

# === Buttons ===
ctk.CTkButton(form_frame, text="Sign Up", fg_color=BUTTON_COLOR, text_color="white",
              width=330, height=40, corner_radius=8, command=register_user).place(x=50, y=580)

ctk.CTkLabel(form_frame, text="Already have an account?", text_color=TEXT_COLOR).place(x=90, y=640)
ctk.CTkButton(form_frame, text="Login", fg_color=LEFT_BG, text_color="white", width=100, height=30,
              border_width=0, command=lambda: [root.destroy(), subprocess.Popen(["python", "login.py"])])\
    .place(x=240, y=636)

# Run
root.mainloop()
