import customtkinter as ctk
import mysql.connector
from tkinter import messagebox
from database import get_db_connection
import subprocess

# === COLORS ===
SIDEBAR_COLOR = "#322F77"
BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"
WINDOW_BG = "#F6F6F6"

class ManageUsers(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Manage Users")
        self.geometry("1000x600")
        self.configure(fg_color=WINDOW_BG)

        # === SIDEBAR ===
        self.sidebar = ctk.CTkFrame(self, width=220, fg_color=SIDEBAR_COLOR)
        self.sidebar.pack(side="left", fill="y")

        ctk.CTkLabel(self.sidebar, text="👤 User Panel", font=("Arial", 20, "bold"), text_color="white").pack(pady=(20, 10))

        self.add_nav_button("➕ Add User", self.show_add_user_form)
        self.add_nav_button("🔄 Refresh Users", self.load_users)

        ctk.CTkLabel(self.sidebar, text="").pack(expand=True)
        self.add_nav_button("⬅ Back to Admin", self.go_back, bottom=True)

        # === MAIN FRAME ===
        self.main_frame = ctk.CTkScrollableFrame(self, fg_color=WINDOW_BG)
        self.main_frame.pack(side="left", fill="both", expand=True)

        self.load_users()

    def add_nav_button(self, text, command, bottom=False):
        btn = ctk.CTkButton(
            self.sidebar, text=text, fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
            hover_color=HIGHLIGHT_COLOR, command=command, width=180
        )
        if bottom:
            btn.pack(side="bottom", pady=15)
        else:
            btn.pack(pady=8, padx=20)

    def clear_main_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

    def load_users(self):
        self.clear_main_frame()

        # === Search & Filter Bar ===
        top_bar = ctk.CTkFrame(self.main_frame, fg_color=WINDOW_BG)
        top_bar.pack(pady=10, padx=20, fill="x")

        search_filter_container = ctk.CTkFrame(top_bar, fg_color=WINDOW_BG)
        search_filter_container.pack(side="left")

        # Search Field
        ctk.CTkLabel(search_filter_container, text="🔍 Search:", text_color=TEXT_COLOR, font=("Arial", 12)).pack(side="left", padx=(0, 5))
        self.search_var = ctk.StringVar()
        search_entry = ctk.CTkEntry(search_filter_container, textvariable=self.search_var, width=200, placeholder_text="Username or Name")
        search_entry.pack(side="left", padx=(0, 20))

        # Status Filter
        ctk.CTkLabel(search_filter_container, text="Status:", text_color=TEXT_COLOR, font=("Arial", 12)).pack(side="left", padx=(0, 5))
        self.status_filter = ctk.CTkOptionMenu(search_filter_container, values=["All", "active", "inactive"])
        self.status_filter.set("All")
        self.status_filter.pack(side="left", padx=(0, 20))

        # Search Button
        ctk.CTkButton(top_bar, text="🔎 Search", fg_color=HIGHLIGHT_COLOR, text_color="white",
                      command=self.apply_filters).pack(side="right", padx=10)

        # Load initial filtered data
        self.apply_filters()

    def apply_filters(self):
        search_text = self.search_var.get().lower()
        selected_status = self.status_filter.get()

        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            query = """
                SELECT u.userid, u.firstname, u.lastname, u.username, u.email, u.phone_number, u.status,
                       COUNT(o.orderid) AS total_orders,
                       GROUP_CONCAT(o.items SEPARATOR ', ') AS order_details
                FROM users u
                LEFT JOIN orders o ON u.userid = o.userid
                WHERE u.role = 'customer'
            """
            params = []

            # Apply filters
            if search_text:
                query += " AND (LOWER(u.firstname) LIKE %s OR LOWER(u.lastname) LIKE %s OR LOWER(u.username) LIKE %s)"
                params.extend([f"%{search_text}%"] * 3)

            if selected_status != "All":
                query += " AND u.status = %s"
                params.append(selected_status)

            query += " GROUP BY u.userid ORDER BY u.firstname"
            cursor.execute(query, params)
            users = cursor.fetchall()
            conn.close()
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", str(e))
            return

        for widget in self.main_frame.winfo_children()[1:]:
            widget.destroy()

        if not users:
            ctk.CTkLabel(self.main_frame, text="No users found.", text_color="red").pack(pady=20)
            return

        for user in users:
            self.create_user_card(user)

    def create_user_card(self, user):
        card = ctk.CTkFrame(self.main_frame, fg_color=BUTTON_COLOR, corner_radius=10)
        card.pack(padx=20, pady=10, fill="x")

        full_name = f"{user['firstname']} {user['lastname']}"
        orders_summary = user['order_details'] if user['order_details'] else "No Orders"

        details = (
            f"👤 {full_name} ({user['username']})\n"
            f"📧 {user['email']} | 📞 {user['phone_number']}\n"
            f"🛒 Orders: {user['total_orders']} - {orders_summary}\n"
            f"✅ Status: {user['status'].capitalize()}"
        )

        ctk.CTkLabel(card, text=details, font=("Arial", 12), text_color=TEXT_COLOR,
                     anchor="w", justify="left").pack(side="left", padx=10, pady=10)

        action_frame = ctk.CTkFrame(card, fg_color=BUTTON_COLOR)
        action_frame.pack(side="right", padx=10)

        ctk.CTkButton(action_frame, text="✏ Edit", fg_color=HIGHLIGHT_COLOR, text_color="white",
                      command=lambda: self.edit_user_popup(user)).pack(pady=3)

        # ❌ Delete option removed

    def show_add_user_form(self):
        self.clear_main_frame()
        ctk.CTkLabel(self.main_frame, text="➕ Add New User", font=("Arial", 20, "bold"),
                     text_color=TEXT_COLOR).pack(pady=20)

        def labeled_entry(label_text):
            ctk.CTkLabel(self.main_frame, text=label_text, text_color=TEXT_COLOR).pack()
            entry = ctk.CTkEntry(self.main_frame, width=400)
            entry.pack(pady=5)
            return entry

        userid = labeled_entry("User ID")
        fname = labeled_entry("First Name")
        lname = labeled_entry("Last Name")
        username = labeled_entry("Username")
        email = labeled_entry("Email")
        phone = labeled_entry("Phone")
        password = labeled_entry("Password")

        def submit_new_user():
            if not all([userid.get(), fname.get(), lname.get(), username.get(), email.get(), phone.get(), password.get()]):
                messagebox.showerror("Error", "All fields are required.")
                return

            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("""INSERT INTO users 
                    (userid, firstname, lastname, username, email, phone_number, password, role, status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, 'customer', 'active')
                """, (userid.get(), fname.get(), lname.get(), username.get(), email.get(), phone.get(), password.get()))
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", "User added successfully.")
                self.load_users()
            except mysql.connector.Error as e:
                messagebox.showerror("Database Error", str(e))

        ctk.CTkButton(self.main_frame, text="✅ Add User", fg_color="green", text_color="white",
                      command=submit_new_user, width=400).pack(pady=20)

    def edit_user_popup(self, user):
        popup = ctk.CTkToplevel(self)
        popup.title(f"Edit User - {user['username']}")
        popup.geometry("400x450")
        popup.grab_set()

        def labeled_entry(label_text, initial=""):
            ctk.CTkLabel(popup, text=label_text, text_color=TEXT_COLOR).pack()
            entry = ctk.CTkEntry(popup, width=300)
            entry.insert(0, initial)
            entry.pack(pady=5)
            return entry

        fname = labeled_entry("First Name", user['firstname'])
        lname = labeled_entry("Last Name", user['lastname'])
        email = labeled_entry("Email", user['email'])
        phone = labeled_entry("Phone", user['phone_number'])

        # Status Dropdown
        ctk.CTkLabel(popup, text="Status", text_color=TEXT_COLOR).pack()
        status_dropdown = ctk.CTkOptionMenu(popup, values=["active", "inactive"])
        status_dropdown.set(user["status"])
        status_dropdown.pack(pady=5)

        def submit_update():
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("""UPDATE users 
                    SET firstname=%s, lastname=%s, email=%s, phone_number=%s, status=%s 
                    WHERE userid=%s""",
                    (fname.get(), lname.get(), email.get(), phone.get(), status_dropdown.get(), user['userid']))
                conn.commit()
                conn.close()
                popup.destroy()
                messagebox.showinfo("Updated", "User updated successfully.")
                self.load_users()
            except mysql.connector.Error as e:
                messagebox.showerror("Database Error", str(e))

        ctk.CTkButton(popup, text="💾 Save", fg_color=HIGHLIGHT_COLOR, text_color="white", command=submit_update).pack(pady=15)

    def go_back(self):
        self.destroy()
        subprocess.Popen(["python", "admin_dashboard.py"])


# Run
if __name__ == "__main__":
    app = ManageUsers()
    app.mainloop()
