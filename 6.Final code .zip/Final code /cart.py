import customtkinter as ctk
import subprocess
import sys
import mysql.connector
from database import get_db_connection

# ========== COLOR SCHEME ==========
BG_COLOR = "#322F77"  # Dark purple background
BUTTON_COLOR = "#FFFFFF"  # White buttons
TEXT_COLOR = "#322F77"  # Dark purple text for buttons
HIGHLIGHT_COLOR = "#4F46E5"  # Blue highlight for links

class Cart(ctk.CTk):
    def __init__(self, user_id):
        super().__init__()

        self.user_id = user_id  # Store logged-in user ID
        print(f"[DEBUG] Cart - User ID: {self.user_id}")  

        self.title("Your Cart")
        self.geometry("600x500")
        self.configure(fg_color=BG_COLOR)

        # Load cart data
        self.cart_items = self.load_cart()

        # ========== HEADER ==========
        ctk.CTkLabel(self, text="🛒 Your Cart", font=("Arial", 20, "bold"), text_color="white", fg_color=BG_COLOR).pack(pady=10)

        # ========== CART FRAME ==========
        self.cart_frame = ctk.CTkScrollableFrame(self, fg_color=BG_COLOR)
        self.cart_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # ========== FOOTER ==========
        self.footer_frame = ctk.CTkFrame(self, fg_color=BG_COLOR)
        self.footer_frame.pack(fill="x", padx=20, pady=10)

        self.total_price_label = ctk.CTkLabel(self.footer_frame, text="Total: $0.00", font=("Arial", 16, "bold"),
                                              text_color="white", fg_color=BG_COLOR)
        self.total_price_label.pack(side="left", padx=10)

        # Buttons
        ctk.CTkButton(self.footer_frame, text="⬅ Back", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      command=self.go_back).pack(side="left", padx=10)
        ctk.CTkButton(self.footer_frame, text="✅ Place Order", fg_color=HIGHLIGHT_COLOR, text_color="white",
                      command=self.place_order).pack(side="right", padx=10)

        # Load Cart Items
        self.update_cart_ui()

    def load_cart(self):
        """Load cart from session file."""
        try:
            with open("cart_session.txt", "r") as file:
                data = eval(file.read())  
                return data.get(self.user_id, {})
        except FileNotFoundError:
            return {}

    def save_cart(self):
        """Save cart to session file."""
        with open("cart_session.txt", "w") as file:
            file.write(str({self.user_id: self.cart_items}))

    def update_cart_ui(self):
        """Refresh cart UI with updated items."""
        for widget in self.cart_frame.winfo_children():
            widget.destroy()

        if not self.cart_items:
            ctk.CTkLabel(self.cart_frame, text="🛒 Your cart is empty!", text_color="white").pack(pady=10)
            self.total_price_label.configure(text="Total: $0.00")
            return

        total_price = 0

        for productid, qty in self.cart_items.items():
            product_info = self.get_product_info(productid)
            if not product_info:
                continue

            name, price = product_info
            total_price += price * qty

            frame = ctk.CTkFrame(self.cart_frame, fg_color=BUTTON_COLOR, corner_radius=10)
            frame.pack(fill="x", pady=5, padx=10)

            details = f"{name}\n💰 ${price} x {qty} = ${price * qty:.2f}"
            ctk.CTkLabel(frame, text=details, font=("Arial", 12), text_color=TEXT_COLOR).pack(side="left", padx=10)

            button_frame = ctk.CTkFrame(frame, fg_color=BUTTON_COLOR)
            button_frame.pack(side="right", padx=10)

            def increase(productid=productid):
                self.cart_items[productid] += 1
                self.save_cart()
                self.update_cart_ui()

            def decrease(productid=productid):
                if self.cart_items[productid] > 1:
                    self.cart_items[productid] -= 1
                else:
                    del self.cart_items[productid]  
                self.save_cart()
                self.update_cart_ui()

            # - Button
            ctk.CTkButton(button_frame, text="➖", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                          command=decrease, width=30, height=30).pack(side="left")

            # Quantity Label
            ctk.CTkLabel(button_frame, text=f"{qty}", font=("Arial", 14, "bold"), text_color=TEXT_COLOR).pack(side="left", padx=5)

            # + Button
            ctk.CTkButton(button_frame, text="➕", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                          command=increase, width=30, height=30).pack(side="left")

        # Update total price label
        self.total_price_label.configure(text=f"Total: ${total_price:.2f}")

    def get_product_info(self, productid):
        """Fetch product name and price from the database."""
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT name, price, stock FROM products WHERE productid = %s", (productid,))
        result = cursor.fetchone()
        conn.close()
        return (result["name"], result["price"]) if result else None

    def place_order(self):
        """Place an order and reduce stock after order placement."""
        if not self.cart_items:
            ctk.CTkLabel(self.cart_frame, text="⚠️ Cart is empty!", text_color="red").pack(pady=10)
            return

        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if user exists
        cursor.execute("SELECT userid FROM users WHERE userid = %s", (self.user_id,))
        user_exists = cursor.fetchone()

        if not user_exists:
            ctk.CTkLabel(self.cart_frame, text="⚠️ Error: User does not exist!", text_color="red").pack(pady=10)
            conn.close()
            return

        # Calculate total price
        total_price = sum(self.get_product_info(pid)[1] * qty for pid, qty in self.cart_items.items())
        order_items = ", ".join([f"{qty}x {self.get_product_info(pid)[0]}" for pid, qty in self.cart_items.items()])

        try:
            # Insert order into `orders` table
            cursor.execute("INSERT INTO orders (userid, items, total_price, status) VALUES (%s, %s, %s, 'pending')",
                        (self.user_id, order_items, total_price))
            conn.commit()

            # Reduce stock in `products` table
            for productid, qty in self.cart_items.items():
                cursor.execute("UPDATE products SET stock = stock - %s WHERE productid = %s", (qty, productid))
                conn.commit()

            # Show success message, clear cart, and redirect
            ctk.CTkLabel(self.cart_frame, text="✅ Order Placed Successfully!", text_color="green").pack(pady=10)
            self.cart_items.clear()
            self.save_cart()
            self.update_cart_ui()

            # Redirect to Customer Dashboard after order placement
            self.after(2000, self.go_back)  

        except mysql.connector.Error as e:
            ctk.CTkLabel(self.cart_frame, text=f"⚠️ Error: {e}", text_color="red").pack(pady=10)

        conn.close()

    def go_back(self):
        """Go back to the Customer Dashboard."""
        print(f"[DEBUG] Returning to Customer Dashboard - User ID: {self.user_id}")  
        self.destroy()
        subprocess.Popen(["python", "customer_dashboard.py", self.user_id])

# Run the Application
if __name__ == "__main__":
    if len(sys.argv) > 1:
        user_id = sys.argv[1]  
        app = Cart(user_id)
        app.mainloop()
    else:
        print("❌ ERROR: No user ID provided!")
