import customtkinter as ctk
import mysql.connector
from tkinter import messagebox, filedialog
from database import get_db_connection
import subprocess

# ========== COLOR SCHEME ==========
BG_COLOR = "#322F77"  # Dark purple background
BUTTON_COLOR = "#FFFFFF"  # White buttons
TEXT_COLOR = "#322F77"  # Dark purple text
HIGHLIGHT_COLOR = "#4F46E5"  # Blue highlight


class AddProduct(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Add Product")
        self.geometry("400x500")
        self.configure(fg_color="#322F77")

        ctk.CTkLabel(self, text="➕ Add New Product", font=("Arial", 16, "bold"), text_color="white").pack(pady=10)

        self.name_entry = ctk.CTkEntry(self, placeholder_text="Product Name", width=300)
        self.name_entry.pack(pady=5)

        self.desc_entry = ctk.CTkEntry(self, placeholder_text="Description", width=300)
        self.desc_entry.pack(pady=5)

        self.price_entry = ctk.CTkEntry(self, placeholder_text="Price", width=300)
        self.price_entry.pack(pady=5)

        self.stock_entry = ctk.CTkEntry(self, placeholder_text="Stock Quantity", width=300)
        self.stock_entry.pack(pady=5)

        self.image_path_var = ctk.StringVar()

        def select_image():
            filepath = filedialog.askopenfilename(title="Select Product Image",
                                                  filetypes=[("Image Files", "*.jpg;*.png;*.jpeg")])
            if filepath:
                self.image_path_var.set(filepath)

        ctk.CTkButton(self, text="📷 Select Image", fg_color="#4F46E5", text_color="white",
                      command=select_image, width=300).pack(pady=5)

        ctk.CTkButton(self, text="✅ Submit", fg_color="green", text_color="white",
                      command=self.submit_product, width=300).pack(pady=10)

        ctk.CTkButton(self, text="⬅ Back", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      command=self.go_back, width=300).pack(pady=5)

    def submit_product(self):
        name = self.name_entry.get().strip()
        desc = self.desc_entry.get().strip()
        price = self.price_entry.get().strip()
        stock = self.stock_entry.get().strip()
        image_path = self.image_path_var.get().strip()

        if not name or not desc or not price or not stock or not image_path:
            messagebox.showerror("Error", "All fields are required!")
            return

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO products (name, description, price, stock, image) VALUES (%s, %s, %s, %s, %s)",
                           (name, desc, float(price), int(stock), image_path))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Product added successfully!")
            self.go_back()
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", str(e))

    def go_back(self):
        """Closes current window and returns to Manage Products."""
        self.destroy()
        subprocess.Popen(["python", "manage_products.py"])

if __name__ == "__main__":
    app = AddProduct()
    app.mainloop()
