import customtkinter as ctk
import mysql.connector
from database import get_db_connection
from tkinter import messagebox, StringVar
import subprocess
import sys

# ========== COLOR SCHEME ==========
BG_COLOR = "#322F77"
BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"

class ChangeOrderStatus(ctk.CTk):
    def __init__(self, orderid, current_status):
        super().__init__()

        self.orderid = orderid
        self.current_status = current_status

        self.title("Change Order Status")
        self.geometry("400x200")
        self.configure(fg_color=BG_COLOR)

        ctk.CTkLabel(self, text=f"Change Status for Order #{self.orderid}", font=("Arial", 16, "bold"),
                     text_color="white").pack(pady=10)

        self.status_var = StringVar(value=self.current_status)

        self.status_dropdown = ctk.CTkOptionMenu(self, values=["pending", "shipped", "delivered"],
                                                 variable=self.status_var, fg_color=BUTTON_COLOR, text_color=TEXT_COLOR)
        self.status_dropdown.pack(pady=10)

        # Update Button
        ctk.CTkButton(self, text="Update", fg_color="green", text_color="white",
                      command=self.update_status).pack(pady=10)

        # Back Button
        ctk.CTkButton(self, text="⬅ Back", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      hover_color=HIGHLIGHT_COLOR, command=self.go_back).pack(pady=5)

    def update_status(self):
        """Update order status in database and return to orders page."""
        new_status = self.status_var.get()
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE orders SET status=%s WHERE orderid=%s", (new_status, self.orderid))
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", f"Order #{self.orderid} status updated to '{new_status}'")

        # Close this window and reopen ManageOrders
        self.destroy()
        subprocess.Popen(["python", "manage_orders.py"])

    def go_back(self):
        """Return to Manage Orders screen without changes."""
        self.destroy()
        subprocess.Popen(["python", "manage_orders.py"])

# Run Application
if __name__ == "__main__":
    if len(sys.argv) > 2:
        orderid = sys.argv[1]
        current_status = sys.argv[2]
        app = ChangeOrderStatus(orderid, current_status)
        app.mainloop()
    else:
        print("❌ ERROR: Order ID and Status required!")
