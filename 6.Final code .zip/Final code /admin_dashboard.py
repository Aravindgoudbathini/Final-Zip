from tkinter import messagebox
import customtkinter as ctk
from PIL import Image
import subprocess
from database import get_db_connection
import mysql.connector
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# === COLORS ===
SIDEBAR_COLOR = "#322F77"
BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"
WINDOW_BG = "#F6F6F6"

class AdminDashboard(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Admin Dashboard")
        self.geometry("1000x600")
        self.configure(fg_color=WINDOW_BG)

        # === SIDEBAR ===
        self.sidebar = ctk.CTkFrame(self, width=220, fg_color=SIDEBAR_COLOR)
        self.sidebar.pack(side="left", fill="y")

        ctk.CTkLabel(self.sidebar, text="🛠️ Admin Panel", font=("Arial", 20, "bold"), text_color="white").pack(pady=(20, 10))

        self.add_nav_button("Home", self.show_home)
        self.add_nav_button("Product Management", self.open_product_management)
        self.add_nav_button("Order Management", self.show_order_management)
        self.add_nav_button("User Management", self.show_user_management)

        ctk.CTkLabel(self.sidebar, text="").pack(expand=True)
        self.add_nav_button("Logout", self.logout, bottom=True)

        # === MAIN FRAME ===
        self.main_frame = ctk.CTkFrame(self, fg_color=WINDOW_BG)
        self.main_frame.pack(side="left", fill="both", expand=True)

        self.show_home()

    def add_nav_button(self, text, command, bottom=False):
        btn = ctk.CTkButton(
            self.sidebar,
            text=text,
            fg_color=BUTTON_COLOR,
            text_color=TEXT_COLOR,
            hover_color=HIGHLIGHT_COLOR,
            command=command,
            width=180
        )
        if bottom:
            btn.pack(side="bottom", pady=15)
        else:
            btn.pack(pady=8, padx=20)

    def clear_main_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

    def show_home(self):
        self.clear_main_frame()

        scroll = ctk.CTkScrollableFrame(self.main_frame, fg_color=WINDOW_BG)
        scroll.pack(fill="both", expand=True, padx=10, pady=10)

        ctk.CTkLabel(scroll, text="📊 Admin Dashboard Summary", font=("Arial", 22, "bold"),
                     text_color=TEXT_COLOR).pack(pady=10)

        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)

            cursor.execute("SELECT orderid, total_price FROM orders ORDER BY orderid")
            order_data = cursor.fetchall()
            order_ids = [row["orderid"] for row in order_data]
            order_prices = [float(row["total_price"]) for row in order_data]

            cursor.execute("SELECT COUNT(*) FROM orders")
            total_orders = cursor.fetchone()["COUNT(*)"]

            cursor.execute("SELECT SUM(total_price) FROM orders")
            total_revenue = float(cursor.fetchone()["SUM(total_price)"] or 0.0)

            cursor.execute("SELECT COUNT(*) FROM users WHERE role='customer'")
            total_customers = cursor.fetchone()["COUNT(*)"]

            conn.close()
        except mysql.connector.Error as e:
            print("DB Error:", e)
            total_orders, total_revenue, total_customers = 0, 0.0, 0
            order_ids, order_prices = [], []

        # === Stats Cards ===
        def stat_card(parent, title, value, emoji):
            frame = ctk.CTkFrame(parent, fg_color=BUTTON_COLOR, corner_radius=8)
            frame.pack(pady=8, padx=20, fill="x")
            ctk.CTkLabel(frame, text=f"{emoji} {title}", font=("Arial", 14, "bold"), text_color=TEXT_COLOR).pack(anchor="w", padx=15)
            ctk.CTkLabel(frame, text=str(value), font=("Arial", 18, "bold"), text_color="#1A237E").pack(anchor="w", padx=15)

        stat_card(scroll, "Total Orders", total_orders, "📦")
        stat_card(scroll, "Total Revenue", f"${total_revenue:.2f}", "💰")
        stat_card(scroll, "Total Customers", total_customers, "👥")

        # === Line Chart ===
        graph1_frame = ctk.CTkFrame(scroll, fg_color=WINDOW_BG)
        graph1_frame.pack(pady=15, padx=20, fill="both", expand=True)

        fig1, ax1 = plt.subplots(figsize=(6, 3), dpi=100)
        ax1.plot(order_ids, order_prices, color="#4F46E5", linewidth=2, marker='o')
        ax1.set_title("Revenue by Order ID")
        ax1.set_xlabel("Order ID")
        ax1.set_ylabel("Revenue ($)")
        ax1.set_facecolor(WINDOW_BG)
        for spine in ax1.spines.values():
            spine.set_visible(False)
        ax1.grid(False)

        canvas1 = FigureCanvasTkAgg(fig1, master=graph1_frame)
        canvas1.draw()
        canvas1.get_tk_widget().pack(fill="both", expand=True)

        # === Bar Chart ===
        graph2_frame = ctk.CTkFrame(scroll, fg_color=WINDOW_BG)
        graph2_frame.pack(pady=15, padx=20, fill="both", expand=True)

        fig2, ax2 = plt.subplots(figsize=(6, 3), dpi=100)
        labels = ['Customers', 'Orders']
        values = [total_customers, total_orders]
        colors = ['#FFA726', '#66BB6A']
        ax2.bar(labels, values, color=colors)
        ax2.set_title("Customer Count vs Order Count")
        ax2.set_facecolor(WINDOW_BG)
        for spine in ax2.spines.values():
            spine.set_visible(False)
        ax2.grid(False)
        for i, v in enumerate(values):
            ax2.text(i, v + 0.2, str(v), ha='center', fontweight='bold')

        canvas2 = FigureCanvasTkAgg(fig2, master=graph2_frame)
        canvas2.draw()
        canvas2.get_tk_widget().pack(fill="both", expand=True)

        # === Download PDF Button ===
        def download_kpi_pdf():
            from reportlab.pdfgen import canvas
            from reportlab.lib.pagesizes import letter
            from tkinter import filedialog
            import os

            file_path = filedialog.asksaveasfilename(
                defaultextension=".pdf",
                filetypes=[("PDF files", "*.pdf")],
                title="Save KPI Report"
            )
            if not file_path:
                return

            try:
                fig1_path = "temp_chart1.png"
                fig2_path = "temp_chart2.png"
                fig1.savefig(fig1_path, bbox_inches="tight")
                fig2.savefig(fig2_path, bbox_inches="tight")

                pdf = canvas.Canvas(file_path, pagesize=letter)
                pdf.setTitle("KPI Report")

                pdf.setFont("Helvetica-Bold", 16)
                pdf.drawString(200, 770, "📊 KPI Dashboard Summary")

                pdf.setFont("Helvetica", 12)
                pdf.drawString(50, 740, f"Total Orders: {total_orders}")
                pdf.drawString(50, 720, f"Total Revenue: ${total_revenue:.2f}")
                pdf.drawString(50, 700, f"Total Customers: {total_customers}")

                pdf.drawImage(fig1_path, 50, 460, width=500, height=200)
                pdf.drawImage(fig2_path, 50, 220, width=500, height=200)

                pdf.save()
                os.remove(fig1_path)
                os.remove(fig2_path)

                messagebox.showinfo("Success", "📥 KPI PDF downloaded successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export PDF:\n{e}")

        ctk.CTkButton(
            scroll,
            text="📥 Download KPI as PDF",
            fg_color="#4F46E5",
            text_color="white",
            font=("Arial", 14),
            command=download_kpi_pdf
        ).pack(pady=(10, 20))

    def open_product_management(self):
        self.destroy()
        subprocess.Popen(["python", "manage_products.py"])

    def show_order_management(self):
        self.clear_main_frame()
        ctk.CTkLabel(self.main_frame, text="📦 Order Management", font=("Arial", 20, "bold"), text_color=TEXT_COLOR).pack(pady=30)
        self.open_script("manage_orders.py")

    def show_user_management(self):
        self.clear_main_frame()
        ctk.CTkLabel(self.main_frame, text="👥 User Management", font=("Arial", 20, "bold"), text_color=TEXT_COLOR).pack(pady=30)
        self.open_script("manage_users.py")

    def open_script(self, script_name):
        self.destroy()
        subprocess.Popen(["python", script_name])

    def logout(self):
        self.destroy()
        subprocess.Popen(["python", "login.py"])

# Run the app
if __name__ == "__main__":
    app = AdminDashboard()
    app.mainloop()
