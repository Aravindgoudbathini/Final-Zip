import customtkinter as ctk
import mysql.connector
from database import get_db_connection
from tkinter import messagebox, StringVar
import subprocess

# ========== COLOR SCHEME ==========
BG_COLOR = "#322F77"
BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"

class ManageOrders(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Order Management")
        self.geometry("600x500")
        self.configure(fg_color=BG_COLOR)

        ctk.CTkLabel(self, text="📋 Manage Orders", font=("Arial", 20, "bold"), text_color="white").pack(pady=10)

        # Scrollable Order List
        self.order_list = ctk.CTkScrollableFrame(self, fg_color=BG_COLOR)
        self.order_list.pack(fill="both", expand=True, padx=20, pady=10)

        # Back Button
        ctk.CTkButton(self, text="⬅ Back to Admin", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      hover_color=HIGHLIGHT_COLOR, command=self.go_back).pack(pady=10)

        # Load Orders
        self.load_orders()

    def load_orders(self):
        """Fetch and display all orders."""
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM orders")
        orders = cursor.fetchall()
        conn.close()

        for order in orders:
            frame = ctk.CTkFrame(self.order_list, fg_color=BUTTON_COLOR, corner_radius=10)
            frame.pack(fill="x", pady=5, padx=10)

            order_details = f"Order #{order['orderid']} - {order['items']} - Status: {order['status']}"
            ctk.CTkLabel(frame, text=order_details, text_color=TEXT_COLOR).pack(side="left", padx=10)

            ctk.CTkButton(frame, text="Change Status", fg_color=HIGHLIGHT_COLOR, text_color="white",
                          command=lambda oid=order['orderid'], status=order['status']: self.change_status(oid, status)).pack(side="right")

    def change_status(self, orderid, current_status):
        """Closes current window and opens a new status change screen."""
        self.destroy()
        subprocess.Popen(["python", "change_order_status.py", str(orderid), current_status])

    def go_back(self):
        """Go back to the Admin Dashboard."""
        self.destroy()
        subprocess.Popen(["python", "admin_dashboard.py"])

# Run Application
if __name__ == "__main__":
    app = ManageOrders()
    app.mainloop()
