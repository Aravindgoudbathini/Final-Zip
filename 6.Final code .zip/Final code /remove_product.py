import customtkinter as ctk
import mysql.connector
from tkinter import messagebox
from database import get_db_connection
import subprocess

# ========== COLOR SCHEME ==========
BG_COLOR = "#322F77"  # Dark purple background
BUTTON_COLOR = "#FFFFFF"  # White buttons
TEXT_COLOR = "#322F77"  # Dark purple text for buttons
HIGHLIGHT_COLOR = "#4F46E5"  # Blue highlight

class RemoveProduct(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Remove Product")
        self.geometry("400x300")
        self.configure(fg_color=BG_COLOR)

        ctk.CTkLabel(self, text="🗑 Remove Product", font=("Arial", 18, "bold"), text_color="white").pack(pady=10)

        self.product_id_entry = ctk.CTkEntry(self, placeholder_text="Enter Product ID", width=300)
        self.product_id_entry.pack(pady=5)

        ctk.CTkButton(self, text="🗑 Delete", fg_color="red", text_color="white",
                      command=self.delete_product, width=300).pack(pady=10)

        ctk.CTkButton(self, text="⬅ Back", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      command=self.go_back, width=300).pack(pady=5)

    def delete_product(self):
        """Deletes the product from the database based on product ID."""
        product_id = self.product_id_entry.get().strip()

        if not product_id:
            messagebox.showerror("Error", "Product ID is required!")
            return

        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            # ✅ Check if the product exists
            cursor.execute("SELECT * FROM products WHERE productid=%s", (int(product_id),))
            product = cursor.fetchone()

            if not product:
                messagebox.showerror("Error", "Product not found!")
                conn.close()
                return

            # ✅ Delete the product
            cursor.execute("DELETE FROM products WHERE productid=%s", (int(product_id),))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Product removed successfully!")
            self.go_back()

        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", str(e))

    def go_back(self):
        """Closes current window and returns to Product Management."""
        self.destroy()
        subprocess.Popen(["python", "manage_products.py"])

if __name__ == "__main__":
    app = RemoveProduct()
    app.mainloop()
