import customtkinter as ctk
import mysql.connector
from tkinter import messagebox
from database import get_db_connection
import subprocess

# ========== COLOR SCHEME ==========
BG_COLOR = "#322F77"  # Dark purple background
BUTTON_COLOR = "#FFFFFF"  # White buttons
TEXT_COLOR = "#322F77"  # Dark purple text
HIGHLIGHT_COLOR = "#4F46E5"  # Blue highlight


class UpdateProduct(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Update Product")
        self.geometry("400x500")
        self.configure(fg_color="#322F77")

        ctk.CTkLabel(self, text="✏ Update Product", font=("Arial", 16, "bold"), text_color="white").pack(pady=10)

        self.product_id_entry = ctk.CTkEntry(self, placeholder_text="Enter Product ID", width=300)
        self.product_id_entry.pack(pady=5)

        self.name_entry = ctk.CTkEntry(self, placeholder_text="New Product Name", width=300)
        self.name_entry.pack(pady=5)

        self.price_entry = ctk.CTkEntry(self, placeholder_text="New Price", width=300)
        self.price_entry.pack(pady=5)

        self.stock_entry = ctk.CTkEntry(self, placeholder_text="New Stock Quantity", width=300)
        self.stock_entry.pack(pady=5)

        ctk.CTkButton(self, text="✅ Update", fg_color="blue", text_color="white",
                      command=self.update_product, width=300).pack(pady=10)

        ctk.CTkButton(self, text="⬅ Back", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      command=self.go_back, width=300).pack(pady=5)

    def update_product(self):
        product_id = self.product_id_entry.get().strip()
        name = self.name_entry.get().strip()
        price = self.price_entry.get().strip()
        stock = self.stock_entry.get().strip()

        if not product_id:
            messagebox.showerror("Error", "Product ID is required!")
            return

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE products SET name=%s, price=%s, stock=%s WHERE productid=%s",
                           (name, float(price), int(stock), int(product_id)))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Product updated successfully!")
            self.go_back()
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", str(e))

    def go_back(self):
        self.destroy()
        subprocess.Popen(["python", "manage_products.py"])

if __name__ == "__main__":
    app = UpdateProduct()
    app.mainloop()
