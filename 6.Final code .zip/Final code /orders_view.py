import customtkinter as ctk
from database import get_db_connection

BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
WINDOW_BG = "#F6F6F6"

class OrdersView:
    def __init__(self, parent, user_id):
        self.user_id = user_id

        ctk.CTkLabel(parent, text="Your Orders", font=("Arial", 20, "bold"), text_color=TEXT_COLOR).pack(pady=10)

        scroll = ctk.CTkScrollableFrame(parent, fg_color=WINDOW_BG)
        scroll.pack(fill="both", expand=True, padx=20, pady=10)

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM orders WHERE userid = %s ORDER BY created_at DESC", (self.user_id,))
        orders = cursor.fetchall()
        conn.close()

        if not orders:
            ctk.CTkLabel(scroll, text="📭 No orders found!", text_color=TEXT_COLOR).pack(pady=20)
            return

        for order in orders:
            self.create_order_card(scroll, order)

    def create_order_card(self, parent, order):
        frame = ctk.CTkFrame(parent, fg_color=BUTTON_COLOR, corner_radius=10)
        frame.pack(fill="x", pady=5, padx=10)

        details = (
            f"Order ID: {order['orderid']}\n"
            f"Items: {order['items']}\n"
            f"Total: ${order['total_price']:.2f}\n"
            f"Date: {order['created_at'].strftime('%Y-%m-%d')}\n"
            f"Status: {order['status'].capitalize()}"
        )
        ctk.CTkLabel(frame, text=details, font=("Arial", 12), text_color=TEXT_COLOR).pack(padx=10, pady=5)
