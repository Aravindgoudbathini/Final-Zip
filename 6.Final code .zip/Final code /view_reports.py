import customtkinter as ctk
import mysql.connector
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import subprocess
from database import get_db_connection

# ========== COLOR SCHEME ==========
BG_COLOR = "#322F77"
BUTTON_COLOR = "#FFFFFF"
TEXT_COLOR = "#322F77"
HIGHLIGHT_COLOR = "#4F46E5"

class ViewReports(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Revenue Reports")
        self.geometry("700x500")
        self.configure(fg_color=BG_COLOR)

        ctk.CTkLabel(self, text="📊 Revenue Reports", font=("Arial", 20, "bold"), text_color="white").pack(pady=10)

        # Frame for Chart
        self.chart_frame = ctk.CTkFrame(self, fg_color=BG_COLOR)
        self.chart_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # Back Button
        ctk.CTkButton(self, text="⬅ Back to Admin", fg_color=BUTTON_COLOR, text_color=TEXT_COLOR,
                      hover_color=HIGHLIGHT_COLOR, command=self.go_back).pack(pady=10)

        # Load Data and Display Chart
        self.load_revenue_chart()

    def load_revenue_chart(self):
        """Fetch revenue data for the last 10 orders and display it as a line graph."""
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT orderid, total_price 
            FROM orders 
            ORDER BY orderid DESC
            LIMIT 10
        """)

        data = cursor.fetchall()
        conn.close()

        if not data:
            ctk.CTkLabel(self.chart_frame, text="⚠️ No Revenue Data Available", text_color="white").pack(pady=20)
            return

        # Reverse data to show in chronological order (earliest to latest)
        data.reverse()

        orders = [f"Order {row['orderid']}" for row in data]  # Label orders as "Order X"
        revenue = [row["total_price"] for row in data]

        # Create figure and axis for Matplotlib
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.plot(orders, revenue, marker="o", linestyle="-", color="#E63946", linewidth=2, markersize=6, label="Revenue ($)")

        ax.set_xlabel("Orders", fontsize=10, fontweight="bold", color="black")  # X-axis is now Orders
        ax.set_ylabel("Revenue ($)", fontsize=10, fontweight="bold", color="black")  # Y-axis is Revenue
        ax.set_title("Revenue Over Last 10 Orders", fontsize=12, fontweight="bold", color="black")
        ax.legend()

        # Remove grid lines
        ax.grid(False)

        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45)

        # Embed Chart in Tkinter
        canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
        canvas.get_tk_widget().pack(fill="both", expand=True)
        canvas.draw()

    def go_back(self):
        """Return to Admin Dashboard."""
        self.destroy()
        subprocess.Popen(["python", "admin_dashboard.py"])

# Run Application
if __name__ == "__main__":
    app = ViewReports()
    app.mainloop()
